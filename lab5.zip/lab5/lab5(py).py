from math import gcd
a, b = map(int,input(
    "Input num1 and num2").split())
print(
    f'GCD num1 and num2 = {gcd(a,b)}\n'
    f'LCM num1 and num2 = {abs(a*b)/gcd(a,b)}'
    )





