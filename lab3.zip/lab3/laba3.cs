﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Math;

namespace laba3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Приклад 1");
            Console.OutputEncoding = Encoding.UTF8;
            Console.WriteLine("Введіть значення х");
            double x = double.Parse(Console.ReadLine());
            double y = Math.Cos(Math.Pow(x,3));
            Console.WriteLine("Результат виразу cos x³ = " + y);
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");


            Console.WriteLine("Приклад 2");
            Console.OutputEncoding = Encoding.UTF8;
            Console.WriteLine("Введіть значення х");
            double a = double.Parse(Console.ReadLine());
            double b = Math.Abs(Math.Cos(a)+1);
            Console.WriteLine("Результат виразу |cosx + 1| =  " + b);
        }
    }
}
