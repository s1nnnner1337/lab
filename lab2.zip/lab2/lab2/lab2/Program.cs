﻿Console.Write("Input a: ");
int a = int.Parse(Console.ReadLine());

Console.Write("Input b: ");
byte b = byte.Parse(Console.ReadLine());

Console.Write("Input c: ");
long c = long.Parse(Console.ReadLine());

Console.WriteLine($"a+b-(a+b+a) = {a + b - (a + b + a)}");
Console.WriteLine($"-a+b-c = {-a + b - c}");
Console.WriteLine($"a-b+c = {a - b + c}");