﻿Console.Write("Input a: ");
byte a = byte.Parse(Console.ReadLine());
Console.Write("Input b: ");
double b = double.Parse(Console.ReadLine());
Console.WriteLine($"a*b = {a * b}");
Console.WriteLine($"a/b-a = {(a / b - a):F2}");