print(
    sum(
        [i*-1 for i in map(int,input(
            ).split(
                ))
         ]
        )
    )