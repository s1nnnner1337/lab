﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("a = ");
        double a = Convert.ToDouble(Console.ReadLine());
        double z1 = Math.Cos(a) + Math.Pow(Math.Cos(a), 3) + Math.Pow(Math.Sin(a), 3);
        Console.WriteLine("z1 = " + z1);

        Console.Write("x = ");
        double x = Convert.ToDouble(Console.ReadLine());
        Console.Write("y = ");
        double y = Convert.ToDouble(Console.ReadLine());
        double z2 = 0.25 - 0.25 * Math.Sin((5.0 / 2) * Math.PI * x - 8 * y);
        Console.WriteLine("z2 = " + z2);
    }
}
